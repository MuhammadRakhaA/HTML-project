function validate(){
    var name = document.getElementById("name");
    var email = document.getElementById("email");
    var phone = document.getElementById("phone");
    var preference = document.getElementById("preference");
    var tnc = document.getElementById("tnc");

    if(name.value.length < 5 ){
        alert('must be a minimum of 5 letters')
        errormsg = "must be a minimum of 5 letters"
        return false
    }
    else if(!email.value.endsWith('@gmail.com')){
        alert('must be a valid email address')
        return false
    }
    else if(isNaN(phone.value)){
        alert('must be a valid phone number')
        return false
    }
    else if (!preference.value){
        alert('pick one preference')
        return false
    }
    else if (!tnc.checked){
        alert('you must agree to terms and conditions')
        return false
    }
    
}